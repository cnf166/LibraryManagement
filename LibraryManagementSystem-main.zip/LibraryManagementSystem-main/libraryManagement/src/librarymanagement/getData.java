/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package librarymanagement;

import java.sql.Date;

/**
 *
 * @author MarcoMan
 * Channel: https://www.youtube.com/channel/UCPgcmw0LXToDn49akUEJBkQ
 * Please support our channel (SUBSCRIBE --> TURN ON NOTIFICATION --> HIT THE LIKE BUTTON)
 */
public class getData {
    
    public static String path;
    public static String studentNumber;
    
    public static String pathImage;
    
    public static String takeBookTitle;
    
//    SAVED DATA
    public static String savedTitle;
    public static String savedAuthor;
    public static String savedGenre;
    public static String savedImage;
    public static Date savedDate;
    
}
